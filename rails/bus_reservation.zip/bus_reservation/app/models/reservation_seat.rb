class ReservationSeat < ApplicationRecord
  belongs_to :reservation
end
