require 'test_helper'

class ReservationSeatTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
